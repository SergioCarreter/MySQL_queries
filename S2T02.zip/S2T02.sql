use tienda;
SELECT nombre FROM producto;
SELECT nombre, precio FROM producto;
SELECT * FROM producto;
SELECT nombre, precio as precio_euros, round(precio/0.95, 2) as precio_USD FROM producto;
SELECT nombre as "nom de producto", precio as euros, round(precio/0.95, 2) as dolars FROM producto;
SELECT 	upper(nombre) as nombre, precio FROM producto;
SELECT 	lower(nombre) as nombre, precio FROM producto;
SELECT 	nombre, upper(substring(nombre, 1, 2)) as codigo FROM fabricante;
SELECT 	nombre, ceil(precio) as precio FROM producto;
SELECT 	nombre, truncate(precio,0) as precio FROM producto;
SELECT codigo_fabricante FROM producto;
SELECT distinct codigo_fabricante FROM producto;
SELECT nombre FROM producto ORDER BY nombre;
SELECT nombre FROM producto ORDER BY nombre DESC;
SELECT nombre FROM producto ORDER BY nombre, precio DESC;
SELECT * FROM fabricante LIMIT 5;
SELECT * FROM fabricante LIMIT 3, 2;
SELECT nombre, precio FROM producto ORDER BY precio LIMIT 1;
SELECT nombre, precio FROM producto ORDER BY precio DESC LIMIT 1;
SELECT nombre FROM producto WHERE codigo_fabricante=2;
SELECT 	p.nombre  as producto, precio, f.nombre as fabricante FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo;
SELECT 	p.nombre  as producto, precio, f.nombre as fabricante FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo ORDER BY f.nombre;
SELECT 	p.codigo  as p_code, p.nombre as producto, p.codigo_fabricante as f_code, f.nombre as fabricante FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo;
SELECT 	p.nombre as producto, p.precio, f.nombre as fabricante FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo ORDER BY p.precio LIMIT 1;
SELECT 	p.nombre as producto, p.precio, f.nombre as fabricante FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo ORDER BY p.precio DESC LIMIT 1;
SELECT * FROM producto WHERE codigo_fabricante=2;
SELECT * FROM producto WHERE codigo_fabricante=6 AND precio>200;
SELECT * FROM producto WHERE codigo_fabricante=1 OR codigo_fabricante=3 OR codigo_fabricante=5;
SELECT * FROM producto WHERE codigo_fabricante IN (1,3,5);
SELECT 	p.nombre  as producto, precio FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo WHERE right(f.nombre,1) = "e";
SELECT 	p.nombre  as producto, precio FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo WHERE locate("w", f.nombre) != 0;
SELECT 	p.nombre as producto, p.precio, f.nombre as fabricante FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo WHERE precio >= 180 ORDER BY precio DESC, p.nombre;
SELECT 	distinct p.codigo_fabricante as f_code, f.nombre as fabricante FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo;
SELECT 	f.nombre as fabricante, p.nombre as producto FROM fabricante f LEFT JOIN producto p ON f.codigo = p.codigo_fabricante ORDER BY f.nombre;
SELECT 	f.nombre as fabricante, p.nombre as producto FROM fabricante f LEFT JOIN producto p ON f.codigo = p.codigo_fabricante WHERE p.nombre IS NULL ORDER BY f.nombre;
SELECT nombre FROM producto p WHERE p.codigo_fabricante=2;
-- 38
SELECT * FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo WHERE f.nombre = "Lenovo" ORDER BY p.precio DESC LIMIT 1;
SELECT * FROM producto p JOIN fabricante f ON p.codigo_fabricante = f.codigo WHERE f.nombre = "Hewlett-Packard" ORDER BY p.precio LIMIT 1;
-- ******************************
-- Universidad
USE universidad;
SELECT apellido1, apellido2, nombre FROM persona ORDER BY apellido1, apellido2, nombre;
SELECT apellido1, apellido2, nombre FROM persona WHERE telefono IS NULL ORDER BY apellido1;
SELECT apellido1, apellido2, nombre FROM persona WHERE fecha_nacimiento <= '1999-12-31' AND fecha_nacimiento >= '1999-01-01' ORDER BY apellido1;
SELECT per.apellido1, per.apellido2, per.nombre FROM profesor prof JOIN persona per ON prof.id_profesor = per.id WHERE right(per.nif,1) = "K" AND per.telefono IS NULL ORDER BY per.apellido1;
SELECT a.nombre FROM asignatura a WHERE cuatrimestre=1 AND curso=3 AND id_grado=7 ORDER BY a.cuatrimestre;
SELECT per.apellido1, per.apellido2, per.nombre, d.nombre as departamento FROM profesor prof JOIN persona per ON prof.id_profesor = per.id JOIN departamento d ON prof.id_departamento = d.id ORDER BY per.apellido1, per.apellido2, per.nombre;
SELECT a.nombre as asignatura, ce.anyo_inicio, ce.anyo_fin FROM persona p JOIN alumno_se_matricula_asignatura ama ON p.id = ama.id_alumno JOIN asignatura a ON ama.id_asignatura = a.id JOIN curso_escolar ce ON ama.id_curso_escolar = ce.id WHERE p.nif= "26902806M";
SELECT DISTINCT d.nombre FROM asignatura a JOIN profesor p ON a.id_profesor = p.id_profesor JOIN departamento d ON p.id_departamento = d.id;
SELECT DISTINCT p.apellido1, p.apellido2, p.nombre FROM alumno_se_matricula_asignatura ama JOIN persona p ON ama.id_alumno = p.id WHERE ama.id_curso_escolar = 5;
-- CONSULTES LEFT JOIN Y RIGHT JOIN
SELECT d.nombre as departamento, per.apellido1, per.apellido2, per.nombre FROM profesor prof JOIN persona per ON prof.id_profesor = per.id LEFT JOIN departamento d ON prof.id_departamento = d.id ORDER BY departamento, per.apellido1, per.apellido2, per.nombre;
SELECT per.apellido1, per.apellido2, per.nombre FROM profesor prof JOIN persona per ON prof.id_profesor = per.id LEFT JOIN departamento d ON prof.id_departamento = d.id WHERE prof.id_departamento IS NULL ORDER BY per.apellido1, per.apellido2, per.nombre;
SELECT d.nombre as departamento FROM departamento d LEFT JOIN profesor p ON d.id = p.id_departamento WHERE p.id_profesor IS NULL ORDER BY d.nombre;
SELECT per.apellido1, per.apellido2, per.nombre FROM profesor p LEFT JOIN asignatura a ON p.id_profesor = a.id_profesor JOIN persona per ON p.id_profesor = per.id WHERE a.id_profesor IS NULL ORDER BY per.apellido1;
SELECT a.nombre as asignatura FROM asignatura a WHERE a.id_profesor IS NULL;
SELECT DISTINCT d.nombre as departamento FROM departamento d LEFT JOIN profesor p ON d.id = p.id_departamento LEFT JOIN asignatura a ON p.id_profesor = a.id_profesor WHERE a.nombre IS NULL;
-- Consultes Resum
SELECT count(*) as num_alumnos FROM persona p WHERE p.tipo = "alumno";
SELECT count(*) as num_alumnos_1999 FROM persona WHERE fecha_nacimiento <= '1999-12-31' AND fecha_nacimiento >= '1999-01-01' AND tipo="alumno";
SELECT d.nombre, count(id_profesor) as num_prof FROM profesor p JOIN departamento d ON p.id_departamento = d.id GROUP BY id_departamento ORDER BY num_prof DESC;
SELECT d.nombre, count(p.id_profesor) as num_prof FROM departamento d LEFT JOIN profesor p ON d.id = p.id_departamento GROUP BY d.id ORDER BY num_prof DESC;
SELECT g.nombre, count(a.id) as num_asign FROM grado g LEFT JOIN asignatura a ON g.id = a.id_grado GROUP BY g.id ORDER BY num_asign DESC;
SELECT  g.nombre, count(a.id) as num_asign FROM grado g JOIN asignatura a ON g.id = a.id_grado WHERE num_asign > 40 GROUP BY g.id ORDER BY num_asign DESC;
SELECT g.nombre, tipo, sum(a.creditos) as credit_sum FROM grado g JOIN asignatura a ON g.id = a.id_grado GROUP BY g.id, tipo;
SELECT ce.anyo_inicio, count(ama.id_alumno) as num_alumnos FROM alumno_se_matricula_asignatura ama JOIN curso_escolar ce ON ama.id_curso_escolar = ce.id GROUP BY ce.id;
SELECT per.id, per.nombre, per.apellido1, per.apellido2, count(a.nombre) as num_asign FROM profesor prof JOIN persona per ON prof.id_profesor = per.id LEFT JOIN asignatura a ON prof.id_profesor = a.id_profesor GROUP BY per.id;
SELECT * FROM persona p WHERE tipo = "alumno" ORDER BY p.fecha_nacimiento DESC LIMIT 1;
SELECT per.id, per.nombre, per.apellido1, per.apellido2 FROM profesor prof JOIN persona per ON prof.id_profesor = per.id LEFT JOIN asignatura a ON prof.id_profesor = a.id_profesor WHERE a.id IS NULL;


